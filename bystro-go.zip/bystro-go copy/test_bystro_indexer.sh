#!/usr/bin/env bash

. ./test_opensearch_server.sh
go run simple_parser.go -http